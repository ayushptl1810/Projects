from flask import Flask, render_template, redirect, url_for, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.sqlite3'

db = SQLAlchemy()
db.init_app(app)
app.app_context().push()
# db = SQLAlchemy(app)


class Student(db.Model):
    student_id = db.Column(db.Integer, primary_key = True, autoincrement = True)
    roll_number = db.Column(db.String(32), unique = True, nullable = False)
    first_name = db.Column(db.String(64), nullable = False)
    last_name = db.Column(db.String(64))

class Course(db.Model):
    course_id = db.Column(db.Integer, primary_key = True, autoincrement = True)
    course_code = db.Column(db.String(32), unique = True, nullable = False)
    course_name = db.Column(db.String(32), nullable = False)
    course_description = db.Column(db.String(1024))

class Enrollments(db.Model):
    enrollment_id = db.Column(db.Integer, primary_key = True, autoincrement = True)
    estudent_id = db.Column(db.Integer, db.ForeignKey(Student.student_id), nullable = False)
    ecourse_id = db.Column(db.Integer, db.ForeignKey(Course.course_id), nullable = False)


# with app.app_context():
#     db.create_all()

@app.route('/')
def index():
    students = Student.query.all()
    if not students:
        return render_template('index.html')
    
    return render_template('index.html', students = students)

@app.route('/student/create')
def add_student():
    return render_template('add_student.html')

@app.route('/student/create', methods = ['POST'])
def add_student_post():
    roll_number = request.form.get('roll')
    first_name = request.form.get('f_name')
    last_name = request.form.get('l_name')
    
    student = Student.query.filter_by(roll_number = roll_number).first()
    
    if student:
        return redirect(url_for('error'))

    new_student = Student(roll_number = roll_number, first_name = first_name, last_name = last_name)
    db.session.add(new_student)
    db.session.commit()

    return redirect(url_for('index'))

@app.route('/error')
def error():
    return render_template('error.html')

@app.route('/student/<string:student_id>/update')
def update_student(student_id):
    student = Student.query.filter_by(student_id = int(student_id)).first()
    enrollments = Enrollments.query.filter_by(estudent_id = int(student_id)).all() 
    courses = Course.query.all()
    selected_courses = [enrollment.ecourse_id for enrollment in Enrollments.query.filter_by(estudent_id=student_id).all()]

    return render_template('update_student.html', student = student, enrollments = enrollments, courses = courses, selected_courses = selected_courses)

@app.route('/student/<string:student_id>/update', methods = ['POST'])
def update_student_post(student_id):

    first_name = request.form.get('f_name')
    last_name = request.form.get('l_name')
    course_ids = request.form.getlist('course')
    
    student = Student.query.filter_by(student_id = int(student_id)).first()

    student.first_name = first_name
    student.last_name = last_name

    enrollments = Enrollments.query.filter_by(estudent_id = int(student_id)).all()
    for items in enrollments:
        db.session.delete(items)
    
    for course_id in course_ids:
        new_enrollment = Enrollments(estudent_id = int(student_id), ecourse_id=int(course_id))
        db.session.add(new_enrollment)

    db.session.commit()
    return redirect(url_for('index'))

@app.route('/student/<int:student_id>/delete')
def delete_student(student_id):
    student = Student.query.get(student_id)
    enrollments = Enrollments.query.filter_by(estudent_id = student_id).all()
    if student:
        db.session.delete(student)  
    
    for items in enrollments:
        db.session.delete(items)  

    db.session.commit() 

    return redirect(url_for('index'))

@app.route('/student/<int:student_id>')
def details_student(student_id):
    student = Student.query.filter_by(student_id=student_id).first()
    enrollments = Enrollments.query.filter_by(estudent_id = student_id).all()

    courses = []
    for enrollment in enrollments:
        course = Course.query.filter_by(course_id=enrollment.ecourse_id).first()
        if course:
            courses.append(course)

    return render_template('details_student.html', student = student, enrollments = enrollments, courses = courses)

@app.route('/course')
def course():
    courses = Course.query.all()
    if not courses:
        return render_template('course.html')
    
    return render_template('course.html', courses = courses)

@app.route('/course/<int:course_id>')
def details_course(course_id):
    course = Course.query.filter_by(course_id=course_id).first()
    enrollments = Enrollments.query.filter_by(ecourse_id = course_id).all()

    students = []
    for enrollment in enrollments:
        student = Student.query.filter_by(student_id = enrollment.estudent_id).first()
        if student:
            students.append(student)

    return render_template('details_course.html', course = course, enrollments = enrollments, students = students)

@app.route('/student/<int:student_id>/withdraw/<int:course_id>')
def withdraw(student_id, course_id):
    enrollment = Enrollments.query.filter_by(estudent_id = student_id, ecourse_id = course_id).first()
    db.session.delete(enrollment)
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/course/create')
def add_course():
    return render_template('add_course.html')

@app.route('/course/create', methods = ['POST'])
def add_course_post():
    course_code = request.form.get('code')
    course_name = request.form.get('c_name')
    course_description = request.form.get('desc')

    course = Course.query.filter_by(course_code = course_code).first()
    if course:
       return redirect(url_for('error'))
    
    new_course = Course(course_code = course_code, course_name = course_name, course_description = course_description)
    db.session.add(new_course)
    db.session.commit()

    return redirect(url_for('course'))

@app.route('/course/<int:course_id>/update')
def update_course(course_id):
    course = Course.query.filter_by(course_id = course_id).first()
    return render_template('update_course.html', course = course)

@app.route('/course/<int:course_id>/update', methods = ['POST'])
def update_course_post(course_id):
    course_name = request.form.get('course_name')
    course_description = request.form.get('course_description')

    course = Course.query.get(course_id)

    course.course_name = course_name
    course.course_description = course_description

    db.session.commit()
    return redirect(url_for('course'))

@app.route('/course/<int:course_id>/delete')
def delete_course(course_id):
    course = Course.query.get(course_id)
    enrollments = Enrollments.query.filter_by(ecourse_id = course_id).all()
    if course:
        db.session.delete(course)  

    for items in enrollments:
        db.session.delete(items)  

    db.session.commit() 
    return redirect(url_for('course'))