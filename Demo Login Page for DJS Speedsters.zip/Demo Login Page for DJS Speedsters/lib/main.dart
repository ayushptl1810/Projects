import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => MyAppState(),
      child: MaterialApp(
        home: LoginPage(),
      ),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var appState = context.watch<MyAppState>();

    return Scaffold(
      body: Container(
        width: 3072,
        height: 1920,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/background_1.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            SizedBox(height: 50),
            Image.asset('assets/logo.png', width: 250, height: 250),
            SizedBox(height: 25),
            Text(
              'DJS SPEEDSTERS',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 36,
                color: Colors.orange,
              ),
            ),
            SizedBox(height: 30),
            Container(
              width: 700,
              height: 380,
              child: Card(
                elevation: 5.0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.0),
                ),
                color: Colors.black,
                child: Padding(
                  padding: EdgeInsets.all(25.0),
                  child: Column(
                    children: [
                      Text('Welcome',
                          style: TextStyle(fontSize: 30, color: Colors.orange)),
                      SizedBox(height: 20),
                      TextField(
                        decoration: InputDecoration(
                            labelText: 'Login ID',
                            border: OutlineInputBorder(),
                            labelStyle: TextStyle(color: Colors.orange)),
                        style: TextStyle(color: Colors.orange),
                      ),
                      SizedBox(height: 20),
                      Stack(
                        children: [
                          TextField(
                            decoration: InputDecoration(
                              labelText: 'Password',
                              border: OutlineInputBorder(),
                              labelStyle: TextStyle(color: Colors.orange),
                            ),
                            style: TextStyle(color: Colors.orange),
                            obscureText: appState._obscureText,
                          ),
                          Positioned(
                            right: 10,
                            bottom: 11,
                            child: IconButton(
                              icon: Icon(appState._obscureText
                                  ? Icons.visibility
                                  : Icons.visibility_off),
                              color: Colors.white,
                              onPressed: () {
                                appState.toggleState();
                              },
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 40),
                      ElevatedButton(
                        onPressed: () {
                          // Implement your login logic
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromARGB(255, 237, 153, 19),
                          foregroundColor: Colors.black,
                        ),
                        child: Text(
                          'Login',
                          style: TextStyle(fontSize: 20, color: Colors.black),
                        ),
                      ),
                      SizedBox(height: 30),
                      InkWell(
                        onTap: () {
                          // Add the code to open the link here
                        },
                        child: Text(
                          'Forgot Password?',
                          style: TextStyle(
                            decoration: TextDecoration.underline,
                            color: Color.fromARGB(255, 238, 159, 49),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MyAppState extends ChangeNotifier {
  var _obscureText = true;

  // ↓ Add this.
  void toggleState() {
    _obscureText = !_obscureText;
    notifyListeners();
  }
}
